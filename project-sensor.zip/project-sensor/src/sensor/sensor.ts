export class Sensor {
    
    id : number;
    nome : string
    localizacao : string;
    tipo : string;
    data : Date;
}